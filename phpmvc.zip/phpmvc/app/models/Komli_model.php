<?php
class Komli_Model
{
    private $Komli = [];
    public function getKomli()
    {
        return $this->Komli;
    }
}
