<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
</head>

<body>
    <div class="container mt-5">
        <div class="card" style="max-width: 1530px;">
            <div class="row no-gutters">
                <div class="col-md-4">
                    <img src="img/gambar1.jpg" class="card-img" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h3 class="card-title">Yoga D. Pamungkas</h3>
                        <p class="card-text">XII RPL C</p>
                        <p class="card-text">02-12-2004</p>
                        <p class="card-text">35</p> 
                    </div>
                </div>
            </div>
        </div>
</body>

</html>