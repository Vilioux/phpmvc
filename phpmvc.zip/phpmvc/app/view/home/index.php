    <div class="container">
        <div class="jumbotron mt-4">
            <h1>Sambutan Kepala SMK NEGERI 2 TRENGGALEK</h1>
            <!-- <p class="lead">Perkenalkan, saya <?= $data['nama']; ?></p> -->
            <hr class="my-4">
            <div class="card" style="max-width: 1289px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="img/gambar6.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <p class="card-text"> Bismillahirohmannirrohim</p>
                            <p>
                                Assalamualaikum Warahmatullah Wabarakatuh
                            </p>
                            Selamat datang di website resmi SMKN 2 Trenggalek.
                            <br>
                            Saya berharap Website ini dapat dijadikan wahana interaksi yang positif
                            <br>
                            baik antar civitas akademika maupun masyarakat pada umumnya sehingga dapat
                            <br>
                            menjalin silaturahmi yang erat disegala unsur. Mari kita bekerja dan berkarya
                            <br>
                            dengan mengharap ridho sang Kuasa dan keikhlasan yang tulus, dijiwai demi anak bangsa.
                            <p>
                                Terima kasih semoga Allah 'Azza Wa Jalla menyertai doa kita semua……aamiin
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>