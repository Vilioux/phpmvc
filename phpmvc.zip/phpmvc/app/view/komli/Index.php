<div class="container">
    <br>
    <h1>Kompetensi Keahlian di SMK Negeri 2 Trenggalek</h1>
    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/RPL.png" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Rekayasa Perangkat Lunak</h2>

                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/TB.jpg" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Kuliner</h2>

                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/DPIB.jpg" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Design Pemodelan dan Informasi Bangunan</h2>

                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/KGSP.jpeg" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Teknik Kontruksi dan Perumahan</h2>

                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/TPTU.jpg" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Teknik Pemanasan, Tata Udara dan Pendinginan</h2>

                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/AKL.png" class="card-img" alt="...">
            </div>
            <div class="col-md-10">
                <div class="card-body">
                    <h2>Akuntansi</h2>

                </div>
            </div>
        </div>
    </div>
    <hr class="my-4">
    <div class="card" style="max-width: 1289px;">
        <div class="row no-gutters">
            <div class="col-md-2">
                <img src="img/SMK.jpg" class="card-img" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h2>Teknik Pengelasan</h2>

                </div>
            </div>
        </div>
    </div>
</div>