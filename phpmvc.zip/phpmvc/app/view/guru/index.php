    <div class="container">
        <br>
        <h3>Daftar Guru</h3>
        <p>
        <h5>Tenaga Pendidik SMKN 2 Trenggalek</h5>
        </p>
    </div>
    <br>
    <div class="container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Nama Guru</th>
                    <th scope="col">Mapel</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ERVI RAHMAWATI, ST</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>IVANS ZUWANTA, S.Kom</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>WAHYU TRI WULYANSARI, S.Pd</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>SAFIRA MAYA SHOVIE, S.Pd</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>NOVI DYAH PUSPITASARI, S.Pd</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>KHOIRUR ROZIQ, S.Pd</td>
                    <td>Pengajar RPL</td>
                </tr>
                <tr>
                    <td>FIKROTU DWI FUADATUZZAHRO</td>
                    <td>Pengajar RPL</td>
                </tr>
            </tbody>
        </table>
    </div>