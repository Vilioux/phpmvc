<?php 
class Komli extends Controller
{
    public function index()
    {
        $data['judul'] = "Komli";
        $data['Komli'] = $this->model('Komli_model')->getKomli();
        $this->view('templates/header', $data);
        $this->view('Komli/index', $data);
        $this->view('templates/footer');
    }
}

